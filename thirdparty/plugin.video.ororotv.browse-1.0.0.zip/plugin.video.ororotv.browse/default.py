# -*- coding: utf-8 -*-
"""
Ororo TV Browse - a Netflix-style way to browse the Ororo.tv catalogue.

Playback is deliberately chained through the Ororo TV add-on so that its HLS
resolution, subtitle handling and the Profanity Filter integration all keep
working exactly as they do when you play from that add-on directly.
"""

import os
import sys

import xbmcaddon

ADDON_PATH = xbmcaddon.Addon().getAddonInfo("path")
sys.path.insert(0, os.path.join(ADDON_PATH, "resources", "lib"))

import nav  # noqa: E402  (path has to be set up first)

if __name__ == "__main__":
    nav.run()
