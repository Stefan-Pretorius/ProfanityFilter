# -*- coding: utf-8 -*-
"""
Navigation and directory listings.

Every screen is a plugin directory keyed by an ?action= parameter, which is what
lets the same code serve both interactive browsing and home-screen widget rows.
"""

import sys
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

import api
import items
import util

WIDGET_DOCS = """\
Any of these can be used as a home-screen widget row in most skins.
In Arctic Zephyr: Mod: Settings > Skin settings > Customise home menu,
add a menu item, then add a widget with a custom path.

FEATURED ROWS
  New Movies                {base}?action=row_new_movies
  Top Rated Movies          {base}?action=row_top_movies
  Popular TV Shows          {base}?action=row_popular_shows
  New TV Shows              {base}?action=row_new_shows
  Top Rated TV Shows        {base}?action=row_top_shows
  My Shows                  {base}?action=row_my_shows

MENUS
  Movies                    {base}?action=menu_movies
  TV Shows                  {base}?action=menu_shows
  Search                    {base}?action=search

BY GENRE (edit the genre name; copy it exactly from By Genre)
  Movies - Action           {base}?action=movie_genre&genre=Action
  Movies - Comedy           {base}?action=movie_genre&genre=Comedy
  Movies - Drama            {base}?action=movie_genre&genre=Drama
  TV - Drama                {base}?action=show_genre&genre=Drama
  TV - Comedy               {base}?action=show_genre&genre=Comedy
  All movie genres          {base}?action=movie_genres
  All TV genres             {base}?action=show_genres

BY OTHER ROUTES
  Best rated movies         {base}?action=movies&sort=rating
  Newest movies             {base}?action=movies&sort=year
  Recently added movies     {base}?action=movies&sort=added
  Movies A-Z                {base}?action=movie_letters
  Movies by year            {base}?action=movie_years
  Movies by rating          {base}?action=movie_ratings
  Best rated TV             {base}?action=shows&sort=rating
  Most popular TV           {base}?action=shows&sort=popular
  TV A-Z                    {base}?action=show_letters
  TV by genre               {base}?action=show_genres
  TV by rating              {base}?action=show_ratings

HOW MANY ITEMS IN A ROW
  Featured rows are capped so your home screen stays fast. Change
  "Items in each featured row" in this add-on's settings.

CACHED CATALOGUE
{cache}
"""


# ---------------------------------------------------------------------------
# small helpers
# ---------------------------------------------------------------------------

def _params():
    if len(sys.argv) > 2 and sys.argv[2]:
        return dict(urllib.parse.parse_qsl(sys.argv[2].lstrip("?")))
    return {}


def _url(base, action, **params):
    params["action"] = action
    return "%s?%s" % (base, urllib.parse.urlencode(params))


def _add(handle, base, action, item, **params):
    xbmcplugin.addDirectoryItem(handle, _url(base, action, **params), item, isFolder=True)


def _add_playable(handle, url, item):
    xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False)


def _resolve_sort_method(name):
    """SORT_METHOD_* in Kodi 18-20, xbmcplugin.SortMethod in Kodi 21+."""
    legacy = getattr(xbmcplugin, "SORT_METHOD_" + name, None)
    enum = getattr(xbmcplugin, "SortMethod", None)
    if enum is not None:
        value = getattr(enum, name, None)
        if value is not None:
            return value
    return legacy


def _sort_methods(handle, names):
    for name in names:
        method = _resolve_sort_method(name)
        if method is None:
            continue
        try:
            xbmcplugin.addSortMethod(handle, method)
        except Exception:
            pass


def _row_limit():
    return max(1, api.row_limit())


# ---------------------------------------------------------------------------
# listings
# ---------------------------------------------------------------------------

def _list_movies(handle, records, limit=0, cache=True, content="movies"):
    xbmcplugin.setContent(handle, content)
    if limit:
        records = records[:limit]
    for record in records:
        url, item, _ = items.movie(record)
        _add_playable(handle, url, item)
    _sort_methods(handle, ("TITLE", "VIDEO_YEAR", "VIDEO_RATING"))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=cache)


def _list_shows(handle, records, base, limit=0, cache=True, sub_action="seasons"):
    xbmcplugin.setContent(handle, "tvshows")
    if limit:
        records = records[:limit]
    for record in records:
        _add(handle, base, sub_action, items.show(record), id=record.get("id"))
    _sort_methods(handle, ("TITLE", "VIDEO_YEAR", "VIDEO_RATING"))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=cache)


def menu(handle, base, entries, cache=False):
    """Render a list of (action, ListItem, params-dict) menu entries."""
    xbmcplugin.setContent(handle, "files")
    for action, item, params in entries:
        _add(handle, base, action, item, **(params or {}))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=cache)


def option(label, plot=""):
    return items.folder(label, plot)


# ---------------------------------------------------------------------------
# home and menus
# ---------------------------------------------------------------------------

def home(handle, base, params):
    rows = (
        ("show_new_movies", "row_new_movies", "New Movies", "Recently added films"),
        ("show_top_movies", "row_top_movies", "Top Rated Movies", "Highest rated films"),
        ("show_new_shows", "row_new_shows", "New TV Shows", "Recently updated series"),
        ("show_popular_shows", "row_popular_shows", "Popular TV Shows", "Most watched series"),
        ("show_top_shows", "row_top_shows", "Top Rated TV Shows", "Highest rated series"),
        ("show_my_shows", "row_my_shows", "My Shows", "Your Ororo TV subscriptions"),
    )
    entries = []
    for setting_name, action, label, plot in rows:
        if api.setting_bool(setting_name, True):
            entries.append((action, option(label, plot), None))

    entries.append(("menu_movies", option("Movies", "The whole film catalogue"), None))
    entries.append(("menu_shows", option("TV Shows", "The whole series catalogue"), None))
    entries.append(("search", option("Search", "Search films and TV shows"), None))
    entries.append(("refresh", option("Refresh Catalogue",
                                      "Re-download the catalogue now"), None))
    entries.append(("help", option("Widget rows and help",
                                  "Paths to use as home-screen widget rows"), None))
    menu(handle, base, entries)


def menu_movies(handle, base, params):
    menu(handle, base, [
        ("movies", option("Recently Added", "Newest additions to the catalogue"), {"sort": "added"}),
        ("movies", option("Best Rated", "Highest IMDb rating first"), {"sort": "rating"}),
        ("movies", option("Newest Releases", "Most recent release year first"), {"sort": "year"}),
        ("movie_letters", option("All Movies (A-Z)", "Browse the catalogue by first letter"), None),
        ("movie_genres", option("By Genre", "Browse films by genre"), None),
        ("movie_years", option("By Year", "Browse films by release year"), None),
        ("movie_ratings", option("By Rating", "Browse films by IMDb rating band"), None),
        ("search_movies", option("Search Movies", "Find a film by title"), None),
    ])


def menu_shows(handle, base, params):
    menu(handle, base, [
        ("shows", option("Recently Added", "Recently updated series first"), {"sort": "added"}),
        ("shows", option("Popular", "Most watched series first"), {"sort": "popular"}),
        ("shows", option("Best Rated", "Highest IMDb rating first"), {"sort": "rating"}),
        ("show_letters", option("All TV Shows (A-Z)", "Browse the catalogue by first letter"), None),
        ("show_genres", option("By Genre", "Browse series by genre"), None),
        ("show_ratings", option("By Rating", "Browse series by IMDb rating band"), None),
        ("my_shows", option("My Shows", "Your Ororo TV subscriptions"), None),
        ("favourite_shows", option("Favourite Shows", "Your Ororo TV favourites"), None),
        ("search_shows", option("Search TV Shows", "Find a series by title"), None),
    ])


# ---------------------------------------------------------------------------
# featured rows (also the widget entry points)
# ---------------------------------------------------------------------------

def _movie_shelf(handle, base, mode):
    records = util.records_for_mode(api.catalogue(util.MOVIES), mode, _row_limit())
    _list_movies(handle, records)


def _show_shelf(handle, base, mode):
    records = util.records_for_mode(api.catalogue(util.SHOWS), mode, _row_limit())
    _list_shows(handle, records, base=base)


def row_new_movies(handle, base, params):
    _movie_shelf(handle, base, "added")


def row_top_movies(handle, base, params):
    _movie_shelf(handle, base, "rating")


def row_new_shows(handle, base, params):
    _show_shelf(handle, base, "added")


def row_popular_shows(handle, base, params):
    _show_shelf(handle, base, "popular")


def row_top_shows(handle, base, params):
    _show_shelf(handle, base, "rating")


def movies(handle, base, params):
    _movie_shelf(handle, base, params.get("sort") or "added")


def shows(handle, base, params):
    _show_shelf(handle, base, params.get("sort") or "added")


# ---------------------------------------------------------------------------
# A-Z, genre, year and rating navigation
# ---------------------------------------------------------------------------

def _letters(handle, base, kind, sub_action):
    records = api.catalogue(kind)
    noun = "film" if kind == util.MOVIES else "series"
    entries = []
    for letter, count in util.letter_buckets(records):
        plot = "%d %s" % (count, noun if count == 1 else noun + "s")
        entries.append((sub_action, option(util.countable_label(letter, count), plot),
                        {"letter": letter}))
    menu(handle, base, entries)


def _genres(handle, base, kind, sub_action):
    records = api.catalogue(kind)
    entries = []
    for genre, count in util.genre_buckets(records):
        entries.append((sub_action, option(util.countable_label(genre, count)),
                        {"genre": genre}))
    menu(handle, base, entries)


def _years(handle, base):
    records = api.catalogue(util.MOVIES)
    entries = []
    for year, count in util.year_buckets(records):
        label = str(year) if year else "Unknown year"
        entries.append(("movie_year", option(util.countable_label(label, count)), {"year": year}))
    menu(handle, base, entries)


def _ratings(handle, base, kind, sub_action):
    records = api.catalogue(kind)
    entries = []
    for label, count in util.rating_buckets(records):
        entries.append((sub_action, option(util.countable_label(label, count)), {"band": label}))
    menu(handle, base, entries)


def movie_letters(handle, base, params):
    _letters(handle, base, util.MOVIES, "movie_letter")


def movie_letter(handle, base, params):
    records = util.filter_records(api.catalogue(util.MOVIES), letter=params.get("letter"))
    _list_movies(handle, util.sort_records(records, "title"))


def movie_genres(handle, base, params):
    _genres(handle, base, util.MOVIES, "movie_genre")


def movie_genre(handle, base, params):
    records = util.filter_records(api.catalogue(util.MOVIES), genre=params.get("genre"))
    _list_movies(handle, util.sort_records(records, "title"))


def movie_years(handle, base, params):
    _years(handle, base)


def movie_year(handle, base, params):
    records = util.filter_records(api.catalogue(util.MOVIES), year=params.get("year"))
    _list_movies(handle, util.sort_records(records, "title"))


def movie_ratings(handle, base, params):
    _ratings(handle, base, util.MOVIES, "movie_rating")


def movie_rating(handle, base, params):
    records = util.filter_records(api.catalogue(util.MOVIES), band=params.get("band"))
    _list_movies(handle, util.sort_records(records, "rating"))


def show_letters(handle, base, params):
    _letters(handle, base, util.SHOWS, "show_letter")


def show_letter(handle, base, params):
    records = util.filter_records(api.catalogue(util.SHOWS), letter=params.get("letter"))
    _list_shows(handle, util.sort_records(records, "title"), base=base)


def show_genres(handle, base, params):
    _genres(handle, base, util.SHOWS, "show_genre")


def show_genre(handle, base, params):
    records = util.filter_records(api.catalogue(util.SHOWS), genre=params.get("genre"))
    _list_shows(handle, util.sort_records(records, "title"), base=base)


def show_ratings(handle, base, params):
    _ratings(handle, base, util.SHOWS, "show_rating")


def show_rating(handle, base, params):
    records = util.filter_records(api.catalogue(util.SHOWS), band=params.get("band"))
    _list_shows(handle, util.sort_records(records, "rating"), base=base)


# ---------------------------------------------------------------------------
# My Shows / favourites (shared with the Ororo TV add-on)
# ---------------------------------------------------------------------------

def my_shows(handle, base, params):
    _watchlist(handle, base, api.watchlist_tokens(),
               "You have not added any shows yet. Add them in the Ororo TV add-on.")


def favourite_shows(handle, base, params):
    _watchlist(handle, base, api.favourite_tokens(),
               "You have no favourite shows yet. Add them in the Ororo TV add-on.")


def row_my_shows(handle, base, params):
    shows = util.filter_watchlist(api.catalogue(util.SHOWS), api.watchlist_tokens())
    _list_shows(handle, shows[:_row_limit()], base=base)


def _watchlist(handle, base, tokens, empty_message):
    shows = util.filter_watchlist(api.catalogue(util.SHOWS), tokens)
    if not shows:
        api.notify(empty_message)
        xbmcplugin.setContent(handle, "tvshows")
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return
    _list_shows(handle, shows, base=base)


# ---------------------------------------------------------------------------
# seasons and episodes
# ---------------------------------------------------------------------------

def _load_show(show_id):
    show = api.show_detail(show_id)
    if not show or not show.get("name"):
        api.notify("Could not load that show.")
        return None
    return show


def seasons(handle, base, params):
    show_id = params.get("id")
    show = _load_show(show_id)
    if show is None:
        xbmcplugin.setContent(handle, "seasons")
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return

    numbers = sorted({util.as_int(ep.get("season"), 1) for ep in (show.get("episodes") or [])})
    xbmcplugin.setContent(handle, "seasons")
    for number in numbers:
        _add(handle, base, "episodes", items.season(show, number), id=show_id, season=number)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def episodes(handle, base, params):
    show_id = params.get("id")
    season = util.as_int(params.get("season"), 1)
    show = _load_show(show_id)
    if show is None:
        xbmcplugin.setContent(handle, "episodes")
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return

    records = [ep for ep in (show.get("episodes") or [])
               if util.as_int(ep.get("season"), 1) == season]
    records.sort(key=lambda ep: util.as_int(ep.get("number"), 0))

    xbmcplugin.setContent(handle, "episodes")
    for record in records:
        url, item, _ = items.episode(show, record)
        _add_playable(handle, url, item)
    _sort_methods(handle, ("EPISODE", "TITLE"))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=True)


# ---------------------------------------------------------------------------
# search
# ---------------------------------------------------------------------------

def search(handle, base, params):
    query = xbmcgui.Dialog().input("Search Ororo TV")
    if not query or not query.strip():
        menu(handle, base, [("home", option("Back to the menu"), None)])
        return
    _search_menu(handle, base, query.strip())


def _search_menu(handle, base, query):
    movies = util.search_records(api.catalogue(util.MOVIES), query)
    shows = util.search_records(api.catalogue(util.SHOWS), query)
    # Counts are shown even when zero here, so an empty result is obvious.
    entries = [
        ("search_movies", option('Movies: "%s" (%d)' % (query, len(movies))),
         {"query": query}),
        ("search_shows", option('TV Shows: "%s" (%d)' % (query, len(shows))),
         {"query": query}),
    ]
    menu(handle, base, entries)


def search_movies(handle, base, params):
    query = params.get("query") or ""
    records = util.search_records(api.catalogue(util.MOVIES), query)
    _list_movies(handle, util.sort_records(records, "title"))


def search_shows(handle, base, params):
    query = params.get("query") or ""
    records = util.search_records(api.catalogue(util.SHOWS), query)
    _list_shows(handle, util.sort_records(records, "title"), base=base)


# ---------------------------------------------------------------------------
# refresh and help
# ---------------------------------------------------------------------------

def refresh(handle, base, params):
    api.invalidate_cache()
    api.notify("Downloading the Ororo catalogue...")
    api.catalogue(util.MOVIES, force=True)
    api.catalogue(util.SHOWS, force=True)
    api.notify("Catalogue refreshed.")
    home(handle, base, params)


def help(handle, base, params):
    text = WIDGET_DOCS.format(base="plugin://" + api.ADDON_ID, cache=api.cache_age_text())
    xbmcgui.Dialog().textviewer("Widget rows and help", text)
    home(handle, base, params)


# ---------------------------------------------------------------------------
# entry point
# ---------------------------------------------------------------------------

def _require_credentials():
    if api.has_credentials():
        return True
    if xbmcgui.Dialog().yesno(
            "Ororo TV Browse",
            "No Ororo account is configured.[CR][CR]"
            "Sign in using the Ororo TV add-on, or enter your details in this "
            "add-on's settings.[CR][CR]Open the Ororo TV add-on settings now?"):
        xbmc.executebuiltin("Addon.OpenSettings(%s)" % util.ORORO_ADDON_ID)
    return False


ROUTES = {
    "home": home,
    "menu_movies": menu_movies,
    "menu_shows": menu_shows,
    "row_new_movies": row_new_movies,
    "row_top_movies": row_top_movies,
    "row_new_shows": row_new_shows,
    "row_popular_shows": row_popular_shows,
    "row_top_shows": row_top_shows,
    "row_my_shows": row_my_shows,
    "movies": movies,
    "shows": shows,
    "movie_letters": movie_letters,
    "movie_letter": movie_letter,
    "movie_genres": movie_genres,
    "movie_genre": movie_genre,
    "movie_years": movie_years,
    "movie_year": movie_year,
    "movie_ratings": movie_ratings,
    "movie_rating": movie_rating,
    "show_letters": show_letters,
    "show_letter": show_letter,
    "show_genres": show_genres,
    "show_genre": show_genre,
    "show_ratings": show_ratings,
    "show_rating": show_rating,
    "my_shows": my_shows,
    "favourite_shows": favourite_shows,
    "seasons": seasons,
    "episodes": episodes,
    "search": search,
    "search_movies": search_movies,
    "search_shows": search_shows,
    "refresh": refresh,
    "help": help,
}


def run():
    handle = int(sys.argv[1])
    base = sys.argv[0]
    params = _params()
    action = params.get("action") or "home"

    handler = ROUTES.get(action)
    if handler is None:
        handler = home

    if action != "help" and not _require_credentials():
        xbmcplugin.setContent(handle, "files")
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return

    try:
        handler(handle, base, params)
    except Exception as error:
        xbmc.log("Ororo TV Browse: %s failed (%s)" % (action, error), xbmc.LOGERROR)
        api.notify("Something went wrong loading that screen.")
        try:
            xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        except Exception:
            pass
