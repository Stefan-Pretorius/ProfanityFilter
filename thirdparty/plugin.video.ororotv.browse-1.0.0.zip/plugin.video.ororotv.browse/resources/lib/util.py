# -*- coding: utf-8 -*-
"""
Pure helpers for Ororo TV Browse.

Nothing in this module imports Kodi, so every function can be unit tested with
plain Python (see tests/test_util.py). The Kodi-facing glue lives in api.py,
items.py and nav.py.
"""

ORORO_ADDON_ID = "plugin.video.ororotv"

# Playback is chained through the Ororo TV add-on on purpose: it already knows
# how to resolve the HLS stream, hand the subtitle to Kodi, and its stream URLs
# contain the media id, which is what the Profanity Filter needs to find the
# subtitle it mutes from.
PLAY_URL = "plugin://plugin.video.ororotv/?action=play&id={media_id}&content_type={kind}"

MOVIES = "movies"
SHOWS = "shows"

# Netflix-style A-Z shelves file "The Matrix" under M, matching Kodi's own
# library behaviour (sorttitle).
LEADING_ARTICLES = ("the ", "a ", "an ")

RATING_BANDS = (
    ("9 and up", 9.0, 10.01),
    ("8 to 9", 8.0, 9.0),
    ("7 to 8", 7.0, 8.0),
    ("6 to 7", 6.0, 7.0),
    ("5 to 6", 5.0, 6.0),
    ("Under 5", 0.0, 5.0),
)

SORT_MODES = (
    ("title", "Title (A-Z)"),
    ("year", "Year (newest first)"),
    ("rating", "Rating (best first)"),
    ("added", "Recently added"),
    ("popular", "Popularity"),
)


# ---------------------------------------------------------------------------
# small conversions
# ---------------------------------------------------------------------------

def as_int(value, default=0):
    """int() that tolerates strings, floats, None and junk."""
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def as_float(value, default=0.0):
    """float() that tolerates strings, None and junk."""
    try:
        return float(str(value).strip())
    except (TypeError, ValueError):
        return default


def unique(values):
    """Order-preserving de-duplication."""
    seen = set()
    result = []
    for value in values:
        if value not in seen:
            seen.add(value)
            result.append(value)
    return result


def imdb_number(record):
    """Return an IMDb id in Kodi's ttNNNNNNN form, or '' when unknown."""
    raw = str(record.get("imdb_id") or "").strip()
    if not raw:
        return ""
    if raw.lower().startswith("tt"):
        return raw
    return "tt" + raw


# ---------------------------------------------------------------------------
# record shaping (raw Ororo API dict -> Kodi infoLabels)
# ---------------------------------------------------------------------------

def title_of(record):
    return (record.get("name") or record.get("title") or "").strip()


def year_of(record):
    return as_int(record.get("year"), 0)


def rating_of(record):
    return as_float(record.get("imdb_rating"), 0.0)


def duration_of(record):
    """Ororo reports length in minutes; Kodi wants seconds."""
    return as_int(record.get("length"), 0) * 60


def genres_of(record):
    genres = record.get("genres") or record.get("array_genres") or []
    if isinstance(genres, str):
        genres = [part.strip() for part in genres.split(",")]
    return [g for g in genres if g]


def countries_of(record):
    countries = record.get("array_countries") or []
    if isinstance(countries, str):
        countries = [countries]
    return [c for c in countries if c]


def sort_title(record):
    """Title normalised for sorting: lowercase, leading article removed."""
    name = title_of(record).lower()
    for article in LEADING_ARTICLES:
        if name.startswith(article):
            return name[len(article):]
    return name


def movie_info(record):
    """Kodi infoLabels for a movie record."""
    info = {
        "mediatype": "movie",
        "title": title_of(record),
        "sorttitle": sort_title(record),
        "plot": record.get("desc") or "",
        "genre": genres_of(record),
        "country": countries_of(record),
        "duration": duration_of(record),
    }
    year = year_of(record)
    if year:
        info["year"] = year
    rating = rating_of(record)
    if rating:
        info["rating"] = rating
    imdb = imdb_number(record)
    if imdb:
        info["imdbnumber"] = imdb
    return info


def show_info(record):
    """Kodi infoLabels for a TV show record."""
    info = {
        "mediatype": "tvshow",
        "title": title_of(record),
        "tvshowtitle": title_of(record),
        "sorttitle": sort_title(record),
        "plot": record.get("desc") or "",
        "genre": genres_of(record),
        "country": countries_of(record),
        "duration": duration_of(record),
        "status": "Ended" if record.get("ended") else "Continuing",
    }
    year = year_of(record)
    if year:
        info["year"] = year
    rating = rating_of(record)
    if rating:
        info["rating"] = rating
    imdb = imdb_number(record)
    if imdb:
        info["imdbnumber"] = imdb
    return info


def episode_info(episode, show):
    """Kodi infoLabels for an episode, borrowing the show's shared fields."""
    number = as_int(episode.get("number"), 0)
    title = (episode.get("name") or "").strip() or "Episode %d" % number
    info = {
        "mediatype": "episode",
        "title": title,
        "tvshowtitle": title_of(show),
        "plot": episode.get("plot") or "",
        "genre": genres_of(show),
        "duration": duration_of(show),
    }
    season = as_int(episode.get("season"), 0)
    if season:
        info["season"] = season
    if number:
        info["episode"] = number
    airdate = (episode.get("airdate") or "").strip()
    if airdate:
        info["aired"] = airdate
        info["premiered"] = airdate
        info["year"] = as_int(airdate[:4], 0) or None
        if not info["year"]:
            del info["year"]
    rating = rating_of(show)
    if rating:
        info["rating"] = rating
    return info


def movie_art(record):
    """setArt() dict for a movie: 2:3 poster plus 16:9 backdrop."""
    poster = record.get("poster_thumb") or ""
    backdrop = record.get("backdrop_url") or poster
    return {
        "poster": poster,
        "thumb": poster,
        "icon": poster,
        "fanart": backdrop,
        "landscape": backdrop,
    }


def show_art(record):
    """setArt() dict for a TV show."""
    poster = record.get("poster_thumb") or ""
    backdrop = record.get("backdrop_url") or poster
    return {
        "poster": poster,
        "thumb": poster,
        "icon": poster,
        "fanart": backdrop,
        "landscape": backdrop,
    }


def episode_art(episode, show):
    """Ororo gives no per-episode stills, so borrow the show's artwork."""
    poster = show.get("poster_thumb") or ""
    backdrop = show.get("backdrop_url") or poster
    return {
        "poster": poster,
        "thumb": backdrop,
        "icon": poster,
        "fanart": backdrop,
        "landscape": backdrop,
    }


# ---------------------------------------------------------------------------
# sorting, filtering and bucketing
# ---------------------------------------------------------------------------

def sort_records(records, mode="title"):
    """Sort records for a shelf. Unknown modes fall back to title."""
    if mode == "year":
        return sorted(records, key=lambda r: (-year_of(r), sort_title(r)))
    if mode == "rating":
        return sorted(records, key=lambda r: (-rating_of(r), sort_title(r)))
    if mode == "added":
        return sorted(records, key=lambda r: (-as_int(r.get("updated_at"), 0), sort_title(r)))
    if mode == "popular":
        return sorted(records, key=lambda r: (
            -as_int(r.get("user_popularity"), 0), -rating_of(r), sort_title(r)))
    return sorted(records, key=sort_title)


def records_for_mode(records, mode, limit=0):
    """Sort, optionally truncate, and return a list."""
    ordered = sort_records(records, mode)
    if limit and limit > 0:
        return ordered[:limit]
    return ordered


def initial_of(record):
    """A-Z shelf bucket: 'A'-'Z', or '#' for anything else."""
    name = sort_title(record).strip()
    if not name:
        return "#"
    letter = name[0].upper()
    return letter if "A" <= letter <= "Z" else "#"


def letter_buckets(records):
    """[('A', 12), ('B', 4), ...] with '#' last."""
    counts = {}
    for record in records:
        letter = initial_of(record)
        counts[letter] = counts.get(letter, 0) + 1
    return sorted(counts.items(), key=lambda item: (item[0] == "#", item[0]))


def year_buckets(records):
    """[(2019, 120), (2018, 98), ...] newest first; undated last."""
    counts = {}
    for record in records:
        year = year_of(record)
        counts[year] = counts.get(year, 0) + 1
    return sorted(counts.items(), key=lambda item: (-item[0],))


def genre_buckets(records):
    """
    [('Action', 812), ...] alphabetical, case-insensitive.

    Spellings that differ only in case are merged (the first one seen wins) so
    the catalogue cannot produce two folders, 'Drama' and 'drama'. Genres are
    also counted once per record: some catalogue entries repeat a genre, which
    would otherwise make the folder's count disagree with its contents.
    """
    counts = {}
    spellings = {}
    for record in records:
        per_record = {}
        for genre in genres_of(record):
            per_record.setdefault(genre.lower(), genre)
        for key, spelling in per_record.items():
            counts[key] = counts.get(key, 0) + 1
            spellings.setdefault(key, spelling)
    return sorted(((spellings[key], count) for key, count in counts.items()),
                  key=lambda item: item[0].lower())


def rating_buckets(records):
    """Rating bands that actually contain something, in RATING_BANDS order."""
    result = []
    for label, low, high in RATING_BANDS:
        count = sum(1 for r in records if low <= rating_of(r) < high)
        if count:
            result.append((label, count))
    return result


def band_range(label):
    """Look a rating band label back up -> (low, high), or None."""
    for band_label, low, high in RATING_BANDS:
        if band_label == label:
            return low, high
    return None


def filter_records(records, letter=None, genre=None, year=None, band=None):
    """Apply the A-Z / genre / year / rating-band filters used by the shelves."""
    result = records
    if letter:
        result = [r for r in result if initial_of(r) == letter]
    if genre:
        wanted = genre.lower()
        result = [r for r in result if wanted in [g.lower() for g in genres_of(r)]]
    if year is not None:
        wanted_year = as_int(year, 0)
        result = [r for r in result if year_of(r) == wanted_year]
    if band:
        limits = band_range(band)
        if limits:
            low, high = limits
            result = [r for r in result if low <= rating_of(r) < high]
    return result


def matches(record, query):
    """Search: every whitespace-separated word must appear in the title."""
    if not query:
        return True
    haystack = title_of(record).lower()
    return all(word in haystack for word in query.lower().split())


def search_records(records, query):
    return [r for r in records if matches(r, query)]


# ---------------------------------------------------------------------------
# sharing the Ororo add-on's My Shows / favourites lists
# ---------------------------------------------------------------------------

def parse_watchlist(text):
    """
    Parse the Ororo TV add-on's subscriptions2.cfg / favourites2.cfg.

    Current format is one quoted id per line (\"1370\"); older builds wrote
    \"id\"|\"name\"|\"...\"|\"imdb\". Every quoted token is collected, so a match
    on any of id / name / imdb id works.
    """
    tokens = set()
    for line in (text or "").splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        parts = [p.strip().strip('"').strip() for p in stripped.split('"|"')]
        for part in parts:
            part = part.strip().strip('"').strip()
            if part:
                tokens.add(part)
    return tokens


def is_in_watchlist(show, tokens):
    """True when a show matches any token from the Ororo add-on's list."""
    if not tokens:
        return False
    candidates = (
        str(show.get("id") or ""),
        title_of(show),
        str(show.get("imdb_id") or ""),
        imdb_number(show),
        str(show.get("tmdb_id") or ""),
        str(show.get("myshows_id") or ""),
    )
    for candidate in candidates:
        if candidate and candidate in tokens:
            return True
    return False


def filter_watchlist(shows, tokens):
    """Shows present in the Ororo add-on's list, alphabetically."""
    return sorted([s for s in shows if is_in_watchlist(s, tokens)], key=sort_title)


# ---------------------------------------------------------------------------
# navigation labels
# ---------------------------------------------------------------------------

def play_url(media_id, kind):
    """The chained Ororo TV add-on playback URL for a movie or episode."""
    return PLAY_URL.format(media_id=as_int(media_id, 0), kind=kind)


def countable_label(label, count):
    """'Action (812)'."""
    return "%s (%d)" % (label, count) if count else label


def short_plot(record, limit=200):
    """Trim a plot for compact contexts (menu descriptions)."""
    plot = (record.get("desc") or record.get("plot") or "").strip()
    if len(plot) <= limit:
        return plot
    cut = plot[:limit]
    # Only drop a trailing word when the cut actually landed mid-word.
    if plot[limit] != " " and " " in cut:
        cut = cut.rsplit(" ", 1)[0]
    return cut.rstrip() + "..."
