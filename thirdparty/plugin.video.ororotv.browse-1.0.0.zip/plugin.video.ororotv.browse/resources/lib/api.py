# -*- coding: utf-8 -*-
"""
Minimal Ororo.tv API client.

This is deliberately self-contained rather than importing the Ororo TV add-on's
modules, so an upstream refactor cannot break us. Credentials are inherited from
the Ororo TV add-on unless they are set in this add-on's settings.

Only three calls are needed for a browsing add-on:
    catalogue("movies")   - every movie (cached on disk)
    catalogue("shows")    - every show  (cached on disk)
    show_detail(show_id)  - one show with its episode list
"""

import base64
import gzip
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import util

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
ORORO_ADDON_ID = util.ORORO_ADDON_ID

# front.ororo.tv is the primary; the mirror is the fallback.
DOMAINS = ("front.ororo.tv", "front.ororo-mirror.tv")
API_SUFFIX = "/api/v2"
TIMEOUT = 25

PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
CATALOGUE_FILE = os.path.join(PROFILE, "catalogue.json")

# Once a domain works, remember it for the rest of the process so we do not pay
# the mirror's timeout again on the next call.
_ACTIVE_DOMAIN = [None]


# ---------------------------------------------------------------------------
# settings
# ---------------------------------------------------------------------------

def setting(name, default=""):
    value = ADDON.getSetting(name)
    return value if value != "" else default


def setting_int(name, default):
    return util.as_int(setting(name), default)


def setting_bool(name, default=True):
    value = ADDON.getSetting(name)
    if value == "":
        return default
    return value.lower() == "true"


def credentials():
    """(user, password) from our settings, else from the Ororo TV add-on."""
    user = setting("user").strip()
    password = setting("password").strip()
    if user and password:
        return user, password

    try:
        ororo = xbmcaddon.Addon(ORORO_ADDON_ID)
        return ororo.getSetting("user").strip(), ororo.getSetting("password").strip()
    except Exception:
        return "", ""


def has_credentials():
    user, password = credentials()
    return bool(user and password)


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------

def _auth_header():
    user, password = credentials()
    if not user or not password:
        return ""
    token = "%s:%s" % (user, password)
    return "Basic " + base64.b64encode(token.encode("utf-8")).decode("ascii")


def _decompress(body, encoding):
    """
    Undo the transfer encoding.

    The Ororo API serves gzip when asked, which takes the catalogue from 5.4MB
    to 1.9MB - worth a lot on a TV. Deflate is handled defensively; the API does
    not currently use it.
    """
    encoding = (encoding or "").lower()
    if encoding == "gzip":
        return gzip.decompress(body)
    if encoding == "deflate":
        try:
            return zlib.decompress(body)
        except zlib.error:
            return zlib.decompress(body, -zlib.MAX_WBITS)
    return body


def _get(uri):
    """
    GET an API path, trying each domain until one answers.

    Returns the raw body bytes (already decompressed), or None when every domain
    failed.
    """
    auth = _auth_header()
    if not auth:
        return None

    ordered = []
    if _ACTIVE_DOMAIN[0]:
        ordered.append(_ACTIVE_DOMAIN[0])
    for domain in DOMAINS:
        if domain not in ordered:
            ordered.append(domain)

    last_error = None
    for domain in ordered:
        url = "https://%s%s%s" % (domain, API_SUFFIX, uri)
        request = urllib.request.Request(url)
        request.add_header("Accept", "application/json")
        request.add_header("Authorization", auth)
        request.add_header("Accept-Encoding", "gzip, deflate")
        request.add_header("User-Agent", "Kodi %s/%s" % (ADDON_NAME, ADDON.getAddonInfo("version")))
        try:
            with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
                body = response.read()
                encoding = response.headers.get("Content-Encoding")
        except urllib.error.HTTPError as error:
            # The host answered, so the domain is fine; the request is not.
            _ACTIVE_DOMAIN[0] = domain
            _notify_http_error(error.code)
            xbmc.log("Ororo TV Browse: HTTP %s on %s%s" % (error.code, domain, uri), xbmc.LOGWARNING)
            return None
        except Exception as error:
            last_error = error
            xbmc.log("Ororo TV Browse: %s unreachable (%s)" % (domain, error), xbmc.LOGWARNING)
            if _ACTIVE_DOMAIN[0] == domain:
                _ACTIVE_DOMAIN[0] = None
            continue

        _ACTIVE_DOMAIN[0] = domain
        try:
            return _decompress(body, encoding)
        except Exception as error:
            # A broken transfer is a data problem, not a domain problem.
            xbmc.log("Ororo TV Browse: bad %s body from %s (%s)"
                     % (encoding, domain, error), xbmc.LOGERROR)
            return None

    xbmc.log("Ororo TV Browse: all API domains failed for %s (%s)" % (uri, last_error), xbmc.LOGERROR)
    notify("Could not reach Ororo. Check your connection.")
    return None


def _notify_http_error(code):
    if code == 401:
        notify("Ororo login failed. Check the account in the Ororo TV add-on.")
    elif code == 402:
        notify("Ororo subscription limit reached.")
    else:
        notify("Ororo returned an error (%s)." % code)


def notify(message):
    """Non-fatal on-screen message."""
    icon = os.path.join(ADDON.getAddonInfo("path"), "icon.png")
    try:
        xbmcgui.Dialog().notification(ADDON_NAME, message, icon, 4000, sound=False)
    except Exception:
        try:
            xbmc.executebuiltin("Notification(%s,%s,4000,%s)" % (ADDON_NAME, message, icon))
        except Exception:
            xbmc.log("Ororo TV Browse: %s" % message, xbmc.LOGWARNING)


def _get_json(uri):
    body = _get(uri)
    if not body:
        return None
    try:
        return json.loads(body.decode("utf-8", errors="replace"))
    except ValueError as error:
        xbmc.log("Ororo TV Browse: bad JSON for %s (%s)" % (uri, error), xbmc.LOGERROR)
        return None


# ---------------------------------------------------------------------------
# catalogue (disk cached)
# ---------------------------------------------------------------------------

def _read_cache():
    try:
        with open(CATALOGUE_FILE, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except Exception:
        return {}


def _write_cache(cache):
    try:
        if not xbmcvfs.exists(PROFILE):
            xbmcvfs.mkdirs(PROFILE)
        with open(CATALOGUE_FILE, "w", encoding="utf-8") as handle:
            json.dump(cache, handle)
    except Exception as error:
        xbmc.log("Ororo TV Browse: could not write catalogue cache (%s)" % error, xbmc.LOGWARNING)


def _cache_hours():
    # settings.xml stores an enum index: 0=6h 1=12h 2=24h 3=48h
    choices = (6, 12, 24, 48)
    index = util.as_int(setting("catalog_hours", "2"), 2)
    if 0 <= index < len(choices):
        return choices[index]
    return 24


def row_limit():
    """How many items a featured row shows (settings enum -> real number)."""
    choices = (50, 100, 200, 500, 1000)
    index = util.as_int(setting("row_limit", "1"), 1)
    if 0 <= index < len(choices):
        return choices[index]
    return 100


def catalogue(kind, force=False):
    """
    Every movie or show, as a list of raw API records.

    Cached on disk for the configured number of hours; a failed refresh falls
    back to the stale copy rather than showing an empty screen.
    """
    cache = _read_cache()
    entry = cache.get(kind) or {}
    items = entry.get("items") or []
    fetched = util.as_int(entry.get("fetched"), 0)
    max_age = _cache_hours() * 3600

    if items and not force and (time.time() - fetched) < max_age:
        return items

    payload = _get_json("/%s" % kind)
    if payload:
        fresh = payload.get(kind) or []
        if fresh:
            cache[kind] = {"fetched": int(time.time()), "items": fresh}
            _write_cache(cache)
            return fresh

    if items:
        xbmc.log("Ororo TV Browse: refresh failed, using cached %s" % kind, xbmc.LOGWARNING)
        return items

    return []


def show_detail(show_id):
    """
    One show including its episode list.

    Not disk cached: it is a single small request and the answer is only needed
    while the user is inside that show.
    """
    payload = _get_json("/shows/%s" % util.as_int(show_id, 0))
    return payload if isinstance(payload, dict) else None


def invalidate_cache():
    """Drop the cached catalogue so the next browse re-downloads it."""
    try:
        if xbmcvfs.exists(CATALOGUE_FILE):
            xbmcvfs.delete(CATALOGUE_FILE)
    except Exception:
        pass


def cache_age_text():
    """Human readable age of the cached catalogue, for the settings/help view."""
    cache = _read_cache()
    parts = []
    for kind in (util.MOVIES, util.SHOWS):
        entry = cache.get(kind) or {}
        count = len(entry.get("items") or [])
        fetched = util.as_int(entry.get("fetched"), 0)
        if fetched:
            hours = (time.time() - fetched) / 3600.0
            parts.append("%s: %d items, %.1fh old" % (kind, count, hours))
        else:
            parts.append("%s: not cached yet" % kind)
    return "\n".join(parts)


# ---------------------------------------------------------------------------
# the Ororo TV add-on's My Shows / favourites lists
# ---------------------------------------------------------------------------

def _ororo_profile_file(name):
    path = "special://profile/addon_data/%s/%s" % (ORORO_ADDON_ID, name)
    return xbmcvfs.translatePath(path)


def _read_profile_file(name):
    try:
        path = _ororo_profile_file(name)
        if not xbmcvfs.exists(path):
            return ""
        handle = xbmcvfs.File(path)
        try:
            return handle.read()
        finally:
            handle.close()
    except Exception:
        return ""


def watchlist_tokens():
    """Ids/names the user added to My Shows in the Ororo TV add-on."""
    return util.parse_watchlist(_read_profile_file("subscriptions2.cfg"))


def favourite_tokens():
    """Ids/names the user favourited in the Ororo TV add-on."""
    return util.parse_watchlist(_read_profile_file("favourites2.cfg"))
