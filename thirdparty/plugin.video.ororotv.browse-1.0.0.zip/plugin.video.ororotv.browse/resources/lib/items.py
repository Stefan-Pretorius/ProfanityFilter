# -*- coding: utf-8 -*-
"""
xbmcgui.ListItem construction.

The metadata mapping itself lives in util.py (pure and unit tested); this module
only binds it to Kodi objects.
"""

import os

import xbmcaddon
import xbmcgui

import util

ADDON_ICON = os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "icon.png")


def _apply(item, info, art, playable=False):
    item.setArt(art)
    item.setInfo("video", info)
    if playable:
        item.setProperty("IsPlayable", "true")
    return item


def movie(record):
    """A playable movie, chained through the Ororo TV add-on."""
    item = xbmcgui.ListItem(util.title_of(record))
    url = util.play_url(record.get("id"), util.MOVIES)
    _apply(item, util.movie_info(record), util.movie_art(record), playable=True)
    return url, item, False


def show(record):
    """A folder listing a show's seasons."""
    item = xbmcgui.ListItem(util.title_of(record))
    _apply(item, util.show_info(record), util.show_art(record))
    return item


def season(show, number):
    """A folder listing one season's episodes."""
    label = "Season %d" % number
    item = xbmcgui.ListItem(label)
    info = {
        "mediatype": "season",
        "title": label,
        "tvshowtitle": util.title_of(show),
        "season": number,
    }
    plot = util.short_plot(show, 400)
    if plot:
        info["plot"] = plot
    _apply(item, info, util.show_art(show))
    return item


def episode(show, record):
    """A playable episode, chained through the Ororo TV add-on."""
    info = util.episode_info(record, show)
    number = util.as_int(record.get("number"), 0)
    title = (record.get("name") or "").strip()
    label = "%d. %s" % (number, title) if title else "Episode %d" % number
    item = xbmcgui.ListItem(label)
    url = util.play_url(record.get("id"), util.SHOWS)
    _apply(item, info, util.episode_art(record, show), playable=True)
    return url, item, False


def folder(label, plot="", art=None, icon=None):
    """A navigation-only entry (genre, letter, year, sort option)."""
    item = xbmcgui.ListItem(label)
    info = {"title": label}
    if plot:
        info["plot"] = plot
    item.setInfo("video", info)
    icons = {"icon": icon or ADDON_ICON}
    if art:
        icons["thumb"] = art
        icons["poster"] = art
    item.setArt(icons)
    return item
